import os
import json
import boto3

ec2 = boto3.client('ec2')

def lambda_handler(event, context):
    print("Received event: " + json.dumps(event))
    
    # Parse the SNS message from the CloudWatch alarm
    sns_message = json.loads(event['Records'][0]['SNS']['Message'])
    
    # Extract the failed instance ID from the alarm dimensions
    dimensions = sns_message['Trigger']['Dimensions']
    failed_instance_id = None
    for dim in dimensions:
        if dim['name'] == 'InstanceId':
            failed_instance_id = dim['value']
            break
            
    if not failed_instance_id:
        print("No InstanceId found in alarm dimensions.")
        return {"status": "No instance ID found"}
        
    print(f"Failed instance detected: {failed_instance_id}. Initiating auto-healing...")
    
    # 1. Terminate the failed instance
    try:
        ec2.terminate_instances(InstanceIds=[failed_instance_id])
        print(f"Successfully terminated failed instance: {failed_instance_id}")
    except Exception as e:
        print(f"Error terminating instance {failed_instance_id}: {str(e)}")
        
    # 2. Launch a replacement instance using environment variables
    ami_id = os.environ['REPLACEMENT_AMI_ID']
    subnet_id = os.environ['REPLACEMENT_SUBNET_ID']
    sg_id = os.environ['REPLACEMENT_SG_ID']
    
    try:
        response = ec2.run_instances(
            ImageId=ami_id,
            InstanceType='t3.micro',
            MinCount=1,
            MaxCount=1,
            SubnetId=subnet_id,
            SecurityGroupIds=[sg_id],
            TagSpecifications=[
                {
                    'ResourceType': 'instance',
                    'Tags': [
                        {
                            'Key': 'Name',
                            'Value': 'cloudops-primary-instance'
                        },
                        {
                            'Key': 'Environment',
                            'Value': 'production'
                        }
                    ]
                }
            ]
        )
        new_instance_id = response['Instances'][0]['InstanceId']
        print(f"Successfully launched replacement instance: {new_instance_id}")
        return {
            "status": "Success",
            "terminated_instance": failed_instance_id,
            "replacement_instance": new_instance_id
        }
    except Exception as e:
        print(f"Error launching replacement instance: {str(e)}")
        raise e